<?php
    $servername = "localhost";
    $username = "easeupgr_admin";
    $password = "!obTk{tGrZY3";
    $database = "easeupgr_crud";
    $conn = mysqli_connect($servername,$username,$password,$database);
    if(!$conn){
        die("Sorry something went wrong");
    }
?>