-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 23, 2023 at 04:12 PM
-- Server version: 10.5.19-MariaDB-cll-lve
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jcmmscho_crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `detail`
--

CREATE TABLE `detail` (
  `sno` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `mobile` text NOT NULL,
  `bookname` text NOT NULL,
  `describe` text NOT NULL,
  `timestamp` varchar(50) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail`
--

INSERT INTO `detail` (`sno`, `name`, `email`, `mobile`, `bookname`, `describe`, `timestamp`) VALUES
(1, 'akshay shriram', 'akshay@gmail.com', '8888702604', 'The monk who sold his FERRAI', 'The best book ever!!!!!', '2020-09-13 16:14:18'),
(2, 'murli krsihna', 'Murli@gmail.com', '8787878787', 'Think and Grow Rich', 'The must read book.', '2020-09-13 16:17:32'),
(3, 'Akshay Shriram', 'shriram1197@gmail.com', '7776017121', 'The Secret', 'awesome!!!!!', '2020-09-13 16:18:16'),
(4, 'Tejas Kshirsagar', 'tejas@gmail.com', '8754679043', 'The Power of Subconscious mind', 'Mind management', '2020-09-13 16:19:18'),
(5, 'Tejas Kshirsagar', 'tejas@gmail.com', '8928120852', 'The Success key System', 'Must read!!!', '2020-09-13 16:19:40'),
(6, 'Shivani Bagal', 'shivani@gmail.com', '7897456387', 'The Monk who SOLD is FERRAI', 'best book for mind mapping', '2020-09-13 16:20:26'),
(7, 'Akshay Shriram', 'akshay@gmail.com', '8888702604', 'Rich Dad And Poor Dad', 'Popular book!!!!', '2020-09-13 16:20:48'),
(8, 'Shrutika', 'shriram1197@gmail.com', '8787878787', 'The Success key System', 'Must read!!!', '2020-09-13 16:21:18'),
(9, 'Shrutika', 'shriram1197@gmail.com', '8787878787', 'The 7 Habits of Highly Effective People', 'Management book', '2020-09-13 16:21:53'),
(10, 'Akshay Shriram', 'asshriram@mitaoe.ac.in', '8888702604', 'The Secret', 'The secret is revealed', '2020-09-13 16:22:21'),
(12, 'Shivani Bagal', 'shivani@gmail.com', '7897456387', 'The Success key System', 'Loving the book', '2020-09-13 16:23:32'),
(13, 'Akshay Shriram', 'asshriram@mitaoe.ac.in', '8787878787', 'The Success key System', 'System is the best explained', '2020-09-13 16:23:57'),
(14, 'Murli', 'Murli@gmail.com', '7776017121', 'Think and Grow Rich', 'Grow rich by thought!!!!', '2020-09-13 16:24:27'),
(15, 'Shrutika', 'shriram1197@gmail.com', '8888702604', 'The Power of Subconscious mind', 'Control over subconsciousness!!!!!!', '2020-09-13 16:25:06'),
(17, 'Akshay Shriram', 'asshriram@mitaoe.ac.in', '8888702604', 'Think and Grow Rich', 'Think BIG', '2020-09-13 11:18:03'),
(18, 'Murli', 'Murli@gmail.com', '8787878787', 'Rich Dad And Poor Dad ', 'the best book', '2020-09-13 11:18:48'),
(19, 'Akshay Shriram', 'asshriram@mitaoe.ac.in', '8888702604', 'The Success key System', 'Success!!!!', '2020-09-13 11:20:47'),
(23, 'Akshay Shriram', 'asshriram@mitaoe.ac.in', '8888702604', 'Test book', 'The book', '2020-09-13 12:39:26'),
(31, 'Akshay Shriram', 'akshayshriram999@gmail.com', '8888702604', 'Death', 'By Sadhguru', '23-04-2023 09:42:11 PM');

-- --------------------------------------------------------

--
-- Table structure for table `userdetail`
--

CREATE TABLE `userdetail` (
  `sno` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `dt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userdetail`
--

INSERT INTO `userdetail` (`sno`, `username`, `password`, `dt`) VALUES
(1, 'akshay', '$2y$10$oDW3yQgHLG4cPdmzZ54o.OpPAUoKH.B09jtscUId.XHTu/kq0Rv0q', '2020-09-20 14:53:00'),
(2, 'akshay1', '$2y$10$8VlKQHiw.uvDHqPazkoA7uGXaRP5TzujzWD0/MZngJXIDVQVlvMgq', '2020-09-20 14:58:57'),
(3, 'HelloWorld', '$2y$10$lGiYY4F1TUzhW.1R54uIJ.C4kMFld.Iup0VM0/SexMRqL3Dm4QcKa', '2020-09-20 15:01:45'),
(4, 'ghfj', '$2y$10$arXLX9BAMFyXdzseJGJU5uMKWDD6xvemNb2sLo3fBiUc/SnOcyTSO', '2020-09-20 15:03:43'),
(5, '1', '$2y$10$IDNOP7AXHxX1SexO5jDTouZXfbyC4IeLXcZUZ3lVJkzk6.ik1BCIu', '2020-09-21 05:18:45'),
(6, 'Srinivas', '$2y$10$6WWZVuQivXu462jFxkKEbO2/l.MvOD7QAM3VBAh4OnRbYU.e.2376', '2020-09-21 05:24:14'),
(7, 'abc', '$2y$10$MYHlhXmIAsiq6bgyWfUd.e55r0IeCr1krtPy0Mb2RanxGwpTLwsNC', '2020-09-21 05:30:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detail`
--
ALTER TABLE `detail`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `userdetail`
--
ALTER TABLE `userdetail`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `detail`
--
ALTER TABLE `detail`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `userdetail`
--
ALTER TABLE `userdetail`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
