<?php
    echo ' <!-- Start Blog -->
    <section id="blog">
        <div class="container py-4">
            <div class="font-sanspro font-size-20">Latest Blogs</div>
            <hr>
            <div class="owl-carousel owl-theme">
                <div class="item">
                    <div class="card-tile mx-2 font-size-16 text-center">
                        <h5>Upcoming Mobiles</h5>
                        <img src="./assets/blog/blog1.jpg" alt="blog1" class="card-img-top">
                        <p class="card-text font-size-14 text-black-50 py-1">Lorem ipsum dolor sit amet consectetur,
                            adipisicing elit. Aut accusantium tenetur ipsum eum dolor voluptatem voluptate
                            asperiores nesciunt, aliquam mollitia, reprehenderit in, magni quis qui?</p>
                        <a href="#" class="btn btn-outline-warning">Go!</a>
                    </div>
                </div>
                <div class="item">
                    <div class="card-tile mx-2 font-size-16 text-center">
                        <h5>Upcoming Mobiles</h5>
                        <img src="./assets/blog/blog2.jpg" alt="blog1" class="card-img-top">
                        <p class="card-text font-size-14 text-black-50 py-1">Lorem ipsum dolor sit amet consectetur,
                            adipisicing elit. Aut accusantium tenetur ipsum eum dolor voluptatem voluptate
                            asperiores nesciunt, aliquam mollitia, reprehenderit in, magni quis qui?</p>
                        <a href="#" class="btn btn-outline-warning">Go!</a>
                    </div>
                </div>
                <div class="item">
                    <div class="card-tile mx-2 font-size-16 text-center">
                        <h5>Upcoming Mobiles</h5>
                        <img src="./assets/blog/blog3.jpg" alt="blog1" class="card-img-top">
                        <p class="card-text font-size-14 text-black-50 py-1">Lorem ipsum dolor sit amet consectetur,
                            adipisicing elit. Aut accusantium tenetur ipsum eum dolor voluptatem voluptate
                            asperiores nesciunt, aliquam mollitia, reprehenderit in, magni quis qui?</p>
                        <a href="#" class="btn btn-outline-warning">Go!</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Blog -->';
?>