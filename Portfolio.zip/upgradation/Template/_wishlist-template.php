<?php 
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        if(isset($_POST['delete-cart-submit'])){
            $cart->deleteCart($_POST['item_id'],'wishlist');
        }
        if(isset($_POST['cart-submit'])){
            $cart->saveForLater($_POST['item_id'],'cart','wishlist');
        }
    }

    
?>

<!-- Start Shopping cart section -->
<section id="cart class=" py-3 mb-5">
        <div class="container-fluid w-75 py-3">
            <h5 class="font-baloo font-size-20">Wishlist</h5>

            <!-- Start Shopping cart items -->
            <div class="row">
                <div class="col-sm-9">
                <?php                    
                   foreach($product->getData('wishlist') as $item):
                    $cart1 = $product->getProduct($item['item_id']);
                    $subtotal[] = array_map(function($item){
                        
                ?>
                    <!-- Start Cart item -->
                    <div class="row border-top py-3 mt-3">
                        <div class="col-sm-2 col-4">
                            <img src="<?php echo $item['item_image'] ?>" alt="product image" style="height: 120px;"
                                class="img-fluid">
                        </div>
                        <div class="col-sm-8">
                            <h5 class="font-baloo font-size-20"><?php echo $item['item_name'] ?></h5>
                            <small>by <?php echo $item['item_brand'] ?></small>
                            <div class="d-flex">
                                <div class="rating text-warning font-size-12">
                                    <span><i class="fas fa-star"></i></span>
                                    <span><i class="fas fa-star"></i></span>
                                    <span><i class="fas fa-star"></i></span>
                                    <span><i class="fas fa-star"></i></span>
                                    <span><i class="far fa-star"></i></span>
                                </div>
                                <a href="#" class="px-2 font-sanspro font-size-14">23,561 rating</a>
                            </div>
                            <!-- Start product qty -->
                            <div class="qty d-flex pt-2">
                                
                                <form method="POST">
                                    <input type="hidden" name="item_id" value="<?php echo $item['item_id'] ?>">
                                    <button type="submit" name="delete-cart-submit" class="btn font-baloo text-danger pl-0 border-right">Delete</button>
                                </form>
                                <form method="post">
                                <input type="hidden" value="<?php echo $item['item_id'] ?? 0; ?>" name="item_id">
                                <button type="submit" name="cart-submit" class="btn font-baloo text-danger">Add To Cart</button>
                                </form>
                                
                            </div>
                            <!-- Endproduct qty -->
                        </div>
                        <div class="col-sm-2 text-right">
                            <div class="font-size-20 text-danger font-baloo">
                                $<span class="product_price" data-id="<?php echo $item['item_id']; ?>"><?php echo $item['item_price'] ?></span>
                            </div>
                        </div>
                    </div>
                <?php 
                return $item["item_price"];
                }, $cart1); //closing array_map function
                endforeach;               
               

                ?>
                    <!-- End Cart item -->
                </div>
                
            </div>
            <!-- End Shopping cart items -->
        </div>
    </section>
    <!-- End Shopping cart section -->  