<?php
    echo '<!-- Start footer -->
    <footer id="footer" class="bg-dark text-white py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-12">
                    <h4 class="font-baloo font-size-20">UpGradation</h4>
                    <p class="font-size-16 text-white font-sanspro">Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit. Explicabo, neque.</p>
                </div>
                <div class="col-lg-5 col-12">
                    <h4 class="font-baloo font-size-20">Newsletter</h4>
                    <form action="" class="form-row">
                        <div class="col">
                            <input type="text" class="form-control" placeholder="email" name="" id="">
                        </div>
                        <div class="col">
                            <button type="submit" class="btn btn-primary mb-2">Subscribe</button>
                        </div>
                    </form>
                </div>
                <div class="col-lg-2 col-12">
                    <h4 class="font-baloo font-size-20">Information</h4>
                    <div class="d-flex flex-column flex-wrap">
                        <a href="#" class="font-sanspro font-size-14 text-white-50 pb-1">About Us</a>
                        <a href="#" class="font-sanspro font-size-14 text-white-50 pb-1">Delivery
                            information</a>
                        <a href="#" class="font-sanspro font-size-14 text-white-50 pb-1">privacy policy</a>
                        <a href="#" class="font-sanspro font-size-14 text-white-50 pb-1">Terms &
                            Condition</a>
                    </div>
                </div>
                <div class="col-lg-2 col-12">
                    <h4 class="font-baloo font-size-20">Account</h4>
                    <div class="d-flex flex-column flex-wrap">
                        <a href="#" class="font-sanspro font-size-14 text-white-50 pb-1">My Account</a>
                        <a href="#" class="font-sanspro font-size-14 text-white-50 pb-1">Order History</a>
                        <a href="#" class="font-sanspro font-size-14 text-white-50 pb-1">Wishlist</a>
                    </div>
                </div>             

            </div>
            <div class="text-center text-white font-size-20">&copy; <a href="#" class="color-secondary">UpGradation</a>  2020-2021</div>
        </div>

    </footer>
    <!-- End footer -->';
?>
