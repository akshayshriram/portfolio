<?php

    //require MySQLi connection
    require('../database/DBconnect.php');

    //require product class
    require('../database/product.php');

    //DBcontroller Object
    $db = new DBcontroller;

    //Product object
    $product = new Product($db);

    if(isset($_POST['itemid'])){
        $result = $product->getProduct($_POST['itemid']);
        echo json_encode($result);
    }
    
?>