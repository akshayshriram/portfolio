<?php 
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        if(isset($_POST['delete-cart-submit'])){
            $cart->deleteCart($_POST['item_id']);
        }

        // save for later
        if (isset($_POST['wishlist-submit'])){
            $cart->saveForLater($_POST['item_id']);
        }
    }
?>

<!-- Start Shopping cart section -->
<section id="cart class=" py-3 mb-5">
        <div class="container-fluid w-75 py-3">
            <h5 class="font-baloo font-size-20">Shoppoing Cart</h5>

            <!-- Start Shopping cart items -->
            <div class="row">
                <div class="col-sm-9">
                <?php                    
                   foreach($product->getData('cart') as $item):
                    $cart1 = $product->getProduct($item['item_id']);
                    $subtotal[] = array_map(function($item){
                        
                ?>
                    <!-- Start Cart item -->
                    <div class="row border-top py-3 mt-3">
                        <div class="col-sm-2 col-4">
                            <img src="<?php echo $item['item_image'] ?>" alt="product image" style="height: 120px;"
                                class="img-fluid">
                        </div>
                        <div class="col-sm-8">
                            <h5 class="font-baloo font-size-20"><?php echo $item['item_name'] ?></h5>
                            <small>by <?php echo $item['item_brand'] ?></small>
                            <div class="d-flex">
                                <div class="rating text-warning font-size-12">
                                    <span><i class="fas fa-star"></i></span>
                                    <span><i class="fas fa-star"></i></span>
                                    <span><i class="fas fa-star"></i></span>
                                    <span><i class="fas fa-star"></i></span>
                                    <span><i class="far fa-star"></i></span>
                                </div>
                                <a href="#" class="px-2 font-sanspro font-size-14">23,561 rating</a>
                            </div>
                            <!-- Start product qty -->
                            <div class="qty d-flex pt-2">
                                <div class="d-flex font-sanspro w-25">  
                                    <button data-id="<?php echo $item['item_id'] ?? '0'; ?>" class="qty-up border bg-light"><i class="fas fa-angle-up"></i></button>
                                    <input type="text" data-id="<?php echo $item['item_id'] ?? '0'; ?>" class="qty_input border px-2 w-100 bg-light" disabled
                                        value="1" placeholder="1">
                                    <button data-id="<?php echo $item['item_id'] ?? '0'; ?>" class="qty-down border bg-light"><i
                                            class="fas fa-angle-down"></i></button>
                                </div>
                                <form method="POST">
                                    <input type="hidden" name="item_id" value="<?php echo $item['item_id'] ?>">
                                    <button type="submit" name="delete-cart-submit" class="btn font-baloo text-danger px-3 border-right">Delete</button>
                                </form>

                                <form method="post">
                                <input type="hidden" value="<?php echo $item['item_id'] ?? 0; ?>" name="item_id">
                                <button type="submit" name="wishlist-submit" class="btn font-baloo text-danger">Save for Later</button>
                                </form>
                                
                            </div>
                            <!-- Endproduct qty -->
                        </div>
                        <div class="col-sm-2 text-right">
                            <div class="font-size-20 text-danger font-baloo">
                                $<span class="product_price"><?php echo $item['item_price'] ?></span>
                            </div>
                        </div>
                    </div>
                <?php 
                return $item["item_price"];
                }, $cart1); //closing array_map function
                endforeach;               
               

                ?>
                    <!-- End Cart item -->
                </div>
                <!-- Start Subtotal section -->
                    <div class="col-sm-3">
                        <div class="sub-total text-center mt-2 border">
                            <h6 class="font-size-12 font-sanspro text-success py-3"><i class="fas fa-check"></i> Your Order is Elgible for FREE Delivery</h6>
                            <div class="border-top py-4">
                                <h5 class="font-size-20 font-baloo">Subtotal {<?php echo isset($subtotal) ? count($product->getData('cart')) : 0 ; ?> item}:&nbsp; <span class="text-danger">$<span class="text-danger" id="deal-price"><?php echo isset($subtotal) ? $cart->getSum($subtotal) : 0 ?></span></span></h5>
                                <button type="success" class="btn btn-success font-size-16 font-sanspro">Proceed To Buy</button>
                                
                            </div>
                        </div>
                    </div>
                <!-- End Subtotal section -->
            </div>
            <!-- End Shopping cart items -->
        </div>
    </section>
    <!-- End Shopping cart section -->