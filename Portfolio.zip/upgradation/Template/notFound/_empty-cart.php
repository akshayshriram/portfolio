

<!-- Start Shopping cart section -->
<section id="cart class=" py-3 mb-5">
        <div class="container-fluid w-75 py-3">
            <h5 class="font-baloo font-size-20">Shoppoing Cart</h5>

            <!-- Start Shopping cart items -->
            <div class="row">
                <div class="col-sm-9">
                <!-- Start Empty cart -->
                    <div class="row border-top py-3 mt-3">
                        <div class="col-sm-12 text-center py-2">
                            <img src="./assets/blog/empty_cart.png" alt="Empty Cart" class="img-fluid" style="height: 200px;">
                            <p class="font-baloo font-size-16 text-black-50">Empty Cart</p>
                        </div>
                    </div>
                <!-- End Empty cart -->
                    
                </div>
                <!-- Start Subtotal section -->
                    <div class="col-sm-3">
                        <div class="sub-total text-center mt-2 border">
                            <h6 class="font-size-12 font-sanspro text-success py-3"><i class="fas fa-check"></i> Your Order is Elgible for FREE Delivery</h6>
                            <div class="border-top py-4">
                                <h5 class="font-size-20 font-baloo">Subtotal {<?php echo isset($subtotal) ? count($product->getData('cart')) : 0 ; ?> item}:&nbsp; <span class="text-danger">$<span class="text-danger" id="deal-price"><?php echo isset($subtotal) ? $cart->getSum($subtotal) : 0 ?></span></span></h5>
                                <button type="success" class="btn btn-success font-size-16 font-sanspro">Proceed To Buy</button>
                                
                            </div>
                        </div>
                    </div>
                <!-- End Subtotal section -->
            </div>
            <!-- End Shopping cart items -->
        </div>
    </section>
    <!-- End Shopping cart section -->