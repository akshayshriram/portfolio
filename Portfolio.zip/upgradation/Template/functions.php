<?php

    //require MySQLi connection
    require('./database/DBconnect.php');

    //require product class
    require('./database/product.php');

    //require cart class
    require('./database/cart.php');
    
    //DBcontroller Object
    $db = new DBcontroller;

    //Product object
    $product = new Product($db);
    $product_shuffle = $product->getData();
    
    //Cart object
    $cart = new cart($db);
   
    
?>