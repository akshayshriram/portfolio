<?php 

    class cart
    {
        public $db = null;
        public function __construct(DBcontroller $db)
        {
            if(!isset($db->conn)) return null;
            $this->db = $db; 
        }

        //insert into cart table
        public function insertintoCart($params = null,$table = "cart"){
            if($this->db->conn !=null){
                if($params != null){
                    //"insert in to cart (uesr_id) values (0)"
                    //get table columns
                    $columns = implode(',', array_keys($params));
                   
                    $values = implode(',', array_values($params));
                    
             
                    //insert sql query
                    $query_string = sprintf("INSERT INTO %s(%s) VALUES(%s)", $table, $columns, $values);

                    $result = $this->db->conn->query($query_string);
                    var_dump($query_string);
                    var_dump($result);
                    return $result;
            
                }
            }   
        }
        public function addToCart($userid,$itemid){
            if(isset($userid) && isset($itemid)){
                
                $params = $arr = array('user_id' =>$userid ,'item_id' =>$itemid );
                $result = $this->insertintoCart($params);

                //insert data into cart
                if($result){
                    // header("location:".$_SERVER['PHP_SELF']);
                    header("location:./index.php");
                }
                return $result;
            }
        }

        // calculate sub total
        public function getSum($arr){
            if(isset($arr)){
                $sum = 0;
                foreach ($arr as $item){
                    $sum += floatval($item[0]);
                }
            return sprintf('%.2f' , $sum);
        }
    }

        //Delete cart item using item_id
        public function deleteCart($item_id = null, $table='cart'){
            if($item_id != null){
                $result = $this->db->conn->query("DELETE FROM {$table} WHERE item_id={$item_id}");
                if($result){
                    header("location:".$_SERVER['PHP_SELF']);
                }
                // return $result;
        }
    }

        //get item_id of shopping cart list
        public function getCartid($cartArray = null, $key = 'item_id'){
            if($cartArray != null){
                $cart_id = array_map(function($value) use($key){
                    return $value[$key];
                },$cartArray);
                return $cart_id;
            }
        }

        //Save For Later
        public function saveForLater($item_id = null, $saveTable = "wishlist", $fromTable = "cart"){
            if ($item_id != null){
                $query = "INSERT INTO {$saveTable} SELECT * FROM {$fromTable} WHERE item_id={$item_id};";
                $query .= "DELETE FROM {$fromTable} WHERE item_id={$item_id};";
    
                // execute multiple query
                $result = $this->db->conn->multi_query($query);
    
                if($result){
                    header("location:".$_SERVER['PHP_SELF']);
                }
                return $result;
            }
        }


}
?>