<!DOCTYPE html>
<html lang="en">
<html>
<?php

ob_start();

//Include Api links
include('API.php');
?>

<body>
    
    <?php
    //Header html file
    include('./Template/_header.php');
    ?>


    <!-- Start main-site -->
    <main id="main-site">
        <?php
            //Banner-area html file
            include('./Template/_banner-area.php');

            //Top-sale html file
            include('./Template/_top-sale.php');

            //Special-price html file
            include('./Template/_special-price.php');

            //include banner-ads html file
            include('./Template/_banner-ads.php');

            //include new-phones html file
            include('./Template/_new-phone.php');

            //include blog html file
            include('./Template/_blog.php');

        ?> 

    </main>
    <!-- End main-site -->

    <?php
        //Footer html file
        include('./Template/_footer.php');

        //All Scripts included
        include('script-link.php');
    ?>
    

    
</body>

</html>