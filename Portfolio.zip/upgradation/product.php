<!DOCTYPE html>
<html lang="en">

<?php
//Include Api links
include('API.php');
?>

<body>
    <?php
    //Header html file
    include('./Template/_header.php');
    ?>


    <!-- Start main-site -->
    <main id="main-site">

        <?php
            //Include product details
            include('./Template/_product.php');

            //Include top-sale html file
            include('./Template/_top-sale.php');
        ?>       

    </main>
    <!-- End main-site -->


    <?php
        //Include footer html file
        include('./Template/_footer.php');

        //Include All script-link file
        include('script-link.php')
    ?>

</body>

</html>