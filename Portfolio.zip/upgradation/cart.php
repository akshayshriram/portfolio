<!DOCTYPE html>
<html lang="en">

<?php
ob_start();

//Include Api links
include('API.php');
?>

<body>
    <?php
    //Header html file
    include('./Template/_header.php');
    ?>


    <!-- Start main-site -->
    <main id="main-site">

        <?php
            //include cart item if it is not empty
            count($product->getData('cart')) ? include('./Template/_cart-template.php'):include('./Template/notFound/_empty-cart.php');


            //include cart item if it is not empty
            count($product->getData('wishlist')) ? include('./Template/_wishlist-template.php'):include('./Template/notFound/_empty-wishlist.php');           

         

            //include new-phones html file
            include('./Template/_new-phone.php');
        ?>

    </main>
    <!-- End main-site -->

    <?php
        //Include footer html file
        include('./Template/_footer.php');

        //Include All script-link file
        include('script-link.php')
    ?>
   
</body>

</html>