
<?php
date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
$timestamp= date('d/m/Y g:i A');
echo $timestamp;
echo '<a href="index.php">index</a>';
?>