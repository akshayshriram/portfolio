<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>iQuote - Discuss Forum</title>
    <link rel="shortcut icon" type="image/x-icon" href="iquote.png">
    <?php
        require 'api.php';      
    ?>
</head>
<?php 
require 'partial/dbconnect.php';
include 'partial/navbar.php';
?>

<body>
    <div class="container" style="min-height: 87.5vh;">
        <h1>
            <?php echo 'Searching for <em>"' . $_GET['search'].'"</em>'; ?>
        </h1>
        <hr>
        
            <?php 
                $noresult = true;
                $query = $_GET['search'];
                $sql = "SELECT * FROM threads WHERE MATCH (thread_title, thread_desc) against ('$query')";
                $result = mysqli_query($conn, $sql);
                $num = mysqli_num_rows($result);
                

                while ($row = mysqli_fetch_assoc($result)) {
                    $threadtitle = $row['thread_title'];
                    $threaddesc = $row['thread_desc'];
                    $user_sno = $row['thread_user_id'];
                    $thread_id = $row['thread_id'] ;
                    
                    $url = "../forum/thread.php?threadid='$thread_id'";
                    echo '<h4><a href="'.$url.'" class="text-dark">'.$threadtitle.'</a>
                    </h4>
                    <p>'.$threaddesc.'.</p>
                    <hr>';
                    $noresult=false;
                    }

                if($noresult){
                    echo '<div class="jumbotron jumbotron-fluid">
                            <div class="container">
                            <p class="display-4">No Search Result Found</p>
                            <p class="lead">Suggestions:
                            <ul>
                            <li>Make sure that all words are spelled correctly.</li>
                            <li>Try different keywords.</li>
                            <li>Try more general keywords.</p></li>
                            </ul>
                    
                            </div>
                        </div>';
                }
                
            ?>
            

    </div>

</body>
<?php
include 'partial/footer.php';
?>

</html>