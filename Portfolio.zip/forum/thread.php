<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>iQuote - Discuss Forum</title>
    <link rel="shortcut icon" type="image/x-icon" href="iquote.png">
    <script>history.pushState({}, "", "")</script>
</head>

<body>
    <?php
    require 'api.php';
    require 'partial/dbconnect.php';
    include 'partial/navbar.php';


    // Display the details of Thread
    $id = $_GET['threadid'];
    
    $sql = "SELECT * FROM `threads` WHERE `thread_id` = $id";
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_assoc($result)) {
        $threadtitle = $row['thread_title'];
        $threaddesc = $row['thread_desc'];
        $user_sno = $row['thread_user_id'];
    }


    ?>
    
    <?php

    //This function is used specially for hosting on webhost

    date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30) 
    $timestamp= date('d/m/Y g:i A');

    // Taking the inputs from form using POST method
    $showresult = false;
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $comment = $_POST['comment'];
        $comment = str_replace("<","&lt;",$comment);
        $comment = str_replace(">","&gt;",$comment);
        $sno = $_POST['sno'];
        $sql = "INSERT INTO `comment` ( `comment_content`, `thread_id`,`comment_by`, `comment_times`) 
        VALUES ('$comment', '$id','$sno', '$timestamp')";
        $result = mysqli_query($conn, $sql);
        $showresult = true;
        if($showresult){
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> Your comment has been added! 
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>';
        }
 
    }

    ?>

    <?php
        // Preview the details of selected thread from threadlist
        $sql = "SELECT * from `users` WHERE sno='$user_sno'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
        


        
        echo '<div class="container">
        <div class="jumbotron my-3">
        <h2 style="font-size:2rem; font-weight: 300;">'. $threadtitle.' </h2>
        <p class="lead"> </p>
        <hr class="my-4">
        <p>'. $threaddesc.'</p>
        <p>Posted By:<b class="font-italic"> '.$row['user_email'].'</b></p>
        </div>';
        ?>
        
        <h4>Add Comments Here</h4>
        <?php
        // Taking the comments as inputs only when user is logged in 
        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true){
            echo '<form action="'. $_SERVER['REQUEST_URI'] .'" method="POST">
    
                <div class="form-group ">
                    <label for="Textarea">Type Your Comment</label>
                    <textarea required class="form-control" id="comment" name="comment" rows="3"></textarea>
                    <input type="hidden" name="sno" value="'.$_SESSION["sno"].'">
                </div>
                <button class="btn btn-success">Post Comment</button>

            </form>';
            
        }
        else{
            echo 
            '<div class="jumbotron jumbotron-fluid py-2">
                <div class="container">
                    
                    <p class="lead">To add comments please login.</p>
                </div>
            </div>';
        }
        ?>

        <h3>Discussion</h3>
        <?php

        // Display all comments of selected thread

        $id = $_GET['threadid'];
        $sql = "SELECT * FROM `comment` WHERE `thread_id` = $id";
        
        $result = mysqli_query($conn, $sql);
        $nocomment = true;
        
        while ($row = mysqli_fetch_assoc($result)) {
         
            $id = $row['comment_id'];
            $content = $row['comment_content'];
            $timestamp = $row['comment_times'];
            $comment_by = $row['comment_by'];
            $nocomment = false;
            
            
            $sql2 = "SELECT user_email from `users` WHERE sno='$comment_by'";
            $result2 = mysqli_query($conn, $sql2);
            $row2 = mysqli_fetch_assoc($result2);
            
            echo '<div class="media border border-dark  " style="margin-bottom: 3rem; padding:1rem;">
            <i class="fa fa-user fa-2x"></i>
            <div class="media-body " >
            <p class="mt-2 text-break" style="margin-left: 8px; ">' . $content . '</p>
            <p class="text-right" style="margin-bottom: 0px;">Posted by:  <b class="font-italic">'.$row2['user_email'].'</b></p> 
            <p class="text-right">'.$timestamp.'</p>
            </div>
            </div>';
        }

        if($nocomment)
        {
            echo '<div class="jumbotron jumbotron-fluid">
            <div class="container">
              <p style="font-size:2rem; ">No Comments Found</p>
              <p class="lead">Be the first one to ask the question.</p>
            </div>
          </div>';

        }



        ?>


    </div>
    <?php
    include 'partial/footer.php';
    ?>
</body>

</html>