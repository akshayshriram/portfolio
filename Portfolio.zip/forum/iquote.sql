-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 06, 2021 at 08:19 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `unaux_29964219_iquote`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `category_description` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `category_description`, `timestamp`) VALUES
(1, 'Python', 'Python is an interpreted, high-level and general-purpose programming language. Created by Guido van Rossum and first released in 1991, Python\'s design philosophy emphasizes code readability with its notable use of significant whitespace. ', '2020-10-19 17:34:00'),
(2, 'JavaScript', 'JavaScript, often abbreviated as JS, is a programming language that conforms to the ECMAScript specification. JavaScript is high-level, often just-in-time compiled, and multi-paradigm.', '2020-10-19 17:34:00'),
(3, 'Java', 'Java is a class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible.', '2020-10-19 17:36:22'),
(4, 'Php', 'PHP is a general-purpose scripting language especially suited to web development. It was originally created by Danish-Canadian programmer Rasmus Lerdorf in 1994.', '2020-10-19 17:36:22');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `comment_id` int(8) NOT NULL,
  `comment_content` text NOT NULL,
  `thread_id` int(8) NOT NULL,
  `comment_by` int(11) NOT NULL,
  `comment_times` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`comment_id`, `comment_content`, `thread_id`, `comment_by`, `comment_times`) VALUES
(1, 'idk ', 1, 3, '20/10/2020 12:29 PM'),
(2, 'i will try to adrees you ASAP..', 2, 1, '22/10/2020 10:27 AM'),
(3, 'sfdg', 2, 5, '23/10/2020 11:47 AM'),
(4, 'Search on google', 5, 2, '24/10/2020 11:57 AM'),
(5, 'idk..............fffffffffffffffffffffffffffdnvlsfdkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkboerrrrrrrrrrrrrrrrrr;mbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbblddddddddddddddddddddddddddddddddddddddddddddddddofjjjjjjjjjjjjjjjjj', 5, 6, '24/10/2020 12:52 PM'),
(6, '\r\nJava is a class-based, object-oriented programming language', 14, 7, '24/10/2020 1:22 PM'),
(7, 'idk check on google..', 3, 8, '26/10/2020 1:42 PM'),
(10, '&lt;script&gt;alert(\"hacked in comment\");&lt;/script&gt;', 17, 4, '24/10/2020 2:02 PM');

-- --------------------------------------------------------

--
-- Table structure for table `threads`
--

CREATE TABLE `threads` (
  `thread_id` int(11) NOT NULL,
  `thread_title` varchar(255) NOT NULL,
  `thread_desc` text NOT NULL,
  `thread_cat_id` int(11) NOT NULL,
  `thread_user_id` int(11) NOT NULL,
  `timestamp` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `threads`
--

INSERT INTO `threads` (`thread_id`, `thread_title`, `thread_desc`, `thread_cat_id`, `thread_user_id`, `timestamp`) VALUES
(1, 'i am unable to install python', 'please help me out!!!!!', 1, 3, '20/10/2020 10:25 AM'),
(2, 'python error', 'python shows error while installing...', 1, 1, '20/10/2020 10:29 AM'),
(3, 'adding API', 'How to add API in Javascript...', 2, 4, '20/10/2020 10:33 PM'),
(4, 'php constructor', 'Is php constructor a public or private function.', 4, 6, '20/10/2020 11:26 PM'),
(5, 'what is python?', 'Elaborate the python.', 1, 5, '20/10/2020 11:40PM'),
(6, 'using date function', 'how to use date function?', 2, 1, '22/10/2020 1:23 PM'),
(7, 'what is Javascript?', 'please elaborate the topic.', 2, 1, '24/10/2020 12:29 PM'),
(11, 'what is the easy way to learn python?', 'Elaborate within 50 words.', 1, 2, '24/10/2020 1:37 PM'),
(12, 'State Java', 'What is Java?', 3, 5, '24/10/2020 1:39 PM'),
(13, 'briefly explain', 'what is the use?', 3, 6, '24/10/2020 2:12 PM'),
(14, 'Java?', 'Explain Java...', 3, 7, '24/10/2020 2:43 PM'),
(15, 'Wine Quality using machine learning', 'Please help me in gathering the database.', 1, 10, '06/10/2021 11:30 AM');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `sno` int(8) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`sno`, `user_email`, `user_pass`, `timestamp`) VALUES
(1, 'akshayshriram999@gmail.com', '$2y$10$wsI8Tzj37mvXKFcZtsDC/.chHlUS.kygnBRMz57KanzaFbCF6cN76', '2020-10-22 18:30:37'),
(2, 'shriram@gmail.com', '$2y$10$OYl62HvJ/58l589V2v5ct.11JZUUG2vvGT1yiyrtXJEuIaR/SSr0K', '2020-10-22 18:30:59'),
(3, 'akshay@gmail.com', '$2y$10$osBf.hpiJ5uO3br/9.8RZO5rGq9AlnUy5GhHatgWwGqmAu1ZYlOaO', '2020-10-22 18:31:21'),
(4, 'ak@ak.com', '$2y$10$1IZhVXRxTgbEdvKMJjif1O0ptcoD1a1fwDJUBU4FCwuzt/vOIpOV2', '2020-10-22 18:31:57'),
(5, 'sh@sh.com', '$2y$10$gKzunkPvCJWavpG9meWA..lI1rOb1WQw/1J4ENhzG8Cag4An9hAj.', '2020-10-22 18:32:33'),
(6, 'akshay@akshay.com', '$2y$10$3fCpiWohmkKwkZKZacTF9eZskzYObf0RMSC6rF9C0gqoT1woBpNxa', '2020-10-22 18:33:11'),
(7, 'akshay', '$2y$10$4QuhN1LCi4zowtYDq6GYoewbI8OO4GRQIopwWJ8i1a4aPZoprbOaq', '2020-10-26 18:51:13'),
(8, 'gh@gh', '$2y$10$fTAwQTP8DTIVUokFlQb7WuvsB5HCd4uHA7grak/UbqGQSyIGYM9n6', '2020-11-01 14:22:51'),
(9, 'swapnil', '$2y$10$ltgHwS1sIpa0sWgMVx.JUOejO2PzeXVhahhKinwCGTvckYenAYaA2', '2021-06-22 19:14:56'),
(10, 'abcd', '$2y$10$YtxDwHMwpDO4BL0om7lgveZkf/l5QUFJgfaxNJk2d6w14s.8A8mPu', '2021-10-06 11:30:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `threads`
--
ALTER TABLE `threads`
  ADD PRIMARY KEY (`thread_id`);
ALTER TABLE `threads` ADD FULLTEXT KEY `thread_title` (`thread_title`,`thread_desc`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `comment_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `threads`
--
ALTER TABLE `threads`
  MODIFY `thread_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `sno` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
