<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>iQuote - Discuss Forum</title>
    <link rel="shortcut icon" type="image/x-icon" href="iquote.png">
    <script>history.pushState({}, "", "")</script>
</head>

<body>
    <?php
    
    require 'api.php';
    require 'partial/dbconnect.php';
    include 'partial/navbar.php';

    // Display the category of selected thread
    $id = $_GET['catid'];
    $sql = "SELECT * FROM `category` WHERE `category_id` = $id";
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_assoc($result)) {
        $catname = $row['category_name'];
        $desc = $row['category_description'];
    }

    ?>

    <?php

    //This function is used specially for hosting on webhost

    date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30) 
    $timestamp= date('d/m/Y g:i A');

    $alert = false;
    $method = $_SERVER['REQUEST_METHOD'];
    if ($method == 'POST') {
        $th_title = $_POST['title'];
        $th_desc = $_POST['desc'];
        $sno = $_POST['sno'];

        $th_title = str_replace("<","&lt;",$th_title);
        $th_title = str_replace(">","&gt;",$th_title);

        
        

        $th_desc = str_replace("<","&lt;",$th_desc);
        $th_desc = str_replace(">","&gt;",$th_desc);


        $sql = "INSERT INTO `threads` (`thread_title`, `thread_desc`, `thread_cat_id`, `thread_user_id`, `timestamp`) 
            VALUES ( '$th_title', '$th_desc', '$id', '$sno', '$timestamp')";
        $result = mysqli_query($conn, $sql);
        $alert = true;
        if ($alert) {
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> Your thread has been added! Please wait our community will soon respond.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>';
        }
    }

    ?>

    <div class="container">
        <div class="jumbotron my-3">
            <h3 class="display-4" >Welcome To <?php echo $catname;  ?> Forum</h3>
            <p class="lead">What is <?php echo $catname;  ?>? Executive Summary</p>
            <hr class="my-4">
            <p><?php echo $desc; ?></p>
            <a class="btn btn-success btn-lg" href="#" role="button">Learn more</a>
        </div>

        <h4>Add Threads Here</h4>
        <?php
            if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                echo '
                <form action="'.$_SERVER['REQUEST_URI'].'" method="POST">
                    <div class="form-group ">
                        <label for="Problem Title">Problem Title</label>
                        <input required type="text" class="form-control" id="title" name="title" aria-describedby="emailHelp">
                        <small id="emailHelp" class="form-text text-muted">keep it short and crisp.</small>
                    </div>
                    <div class="form-group ">
                        <label for="Textarea">Ellaborate your concern</label>
                        <textarea required class="form-control" id="desc" name="desc" rows="3"></textarea>
                        <input type="hidden" name="sno" value="'.$_SESSION["sno"].'">
                    </div>
                    <button class="btn btn-success">Submit</button>
    
                </form>';
            }
            else{
                echo 
                '<div class="jumbotron jumbotron-fluid py-2">
                    <div class="container">
                        
                        <p class="lead">To add threads please login.</p>
                    </div>
                </div>';
            }
        ?>
            
    
        <h3>Browse Question</h3>
        <?php
        $sql = "SELECT * FROM `threads` WHERE `thread_cat_id` = $id";
        $result = mysqli_query($conn, $sql);
        $num = mysqli_num_rows($result);
        if ($num == 0) {
            echo '<div class="jumbotron jumbotron-fluid">
                <div class="container">
                  <p class="display-4">No Threads Found</p>
                  <p class="lead">Be the first one to ask the question.</p>
                </div>
              </div>';
        } else {

            while ($row = mysqli_fetch_assoc($result)) {
                $thread_id = $row['thread_id'];
                $title = $row['thread_title'];
                $tdesc = $row['thread_desc'];
                $thread_time = $row['timestamp'];
                $thread_user_id = $row['thread_user_id'];
                $sql2 = "SELECT * from `users` WHERE sno='$thread_user_id'";
                $result2 = mysqli_query($conn, $sql2);
                $row2 = mysqli_fetch_assoc($result2);


                echo '<div class="media border border-dark  " style="margin-bottom: 3rem; padding:1rem">
                <i class="fa fa-user fa-2x "></i>
                <div class="media-body " >
                
                <h5 class="mt-2 mx-2"><a class="text-dark text-break text-decoration-none" href = "thread.php?threadid=' . $thread_id . '">' . $title . '</a></h5>'.'

                <p class="mx-2 text-break" >' . $tdesc .'
                </p>'.'<p class="  text-right" style="margin-bottom: 0px;">
                Posted by: <b class="font-italic">'.$row2['user_email'].'</b></p> 
                 <p class="text-right">'.$thread_time.'</p>
                </div>
                </div>';
            }
        }
        ?>
    </div>
    <?php
    include 'partial/footer.php';
    ?>
</body>

</html>