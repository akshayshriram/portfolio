<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>iQuote - Discuss Forum</title>
    <link rel="shortcut icon" type="image/x-icon" href="iquote.png">
    <?php
        require 'api.php';      
    ?> 
</head>

<body>

    <?php 
    require 'partial/dbconnect.php';
    require 'partial/navbar.php';
    ?>
    <!-- Carousel for the slide images -->
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators"> 
           
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="IMG1.jpg" class="d-block w-100 " style="height: 30vw;" alt="...">
            </div>
            <div class="carousel-item">
                <img src="IMG2.jpg" class="d-block w-100 " style="height: 30vw;" alt="...">
            </div>
            <div class="carousel-item">
                <img src="IMG3.jpg" class="d-block w-100 " style="height: 30vw;" alt="...">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <div class="container">
        <h3 class="text-center my-3">iQuote - Category</h3>
        <div class="row ">
            <!-- Cards  category using a loop -->
            <?php
            $sql = "SELECT * FROM `category`";
            $result = mysqli_query($conn, $sql);
            $count = 0;
            while ($row = mysqli_fetch_assoc($result)) {
                  
                $id =  $row['category_id'];
                $cat =  $row['category_name'];
                $desc = $row['category_description'];
                $count = $count + 1;
                
                echo '<div class="d-flex justify-content-center my-3 col-lg-4 col-sm-12">
                <div class="card" style="width: 18rem;height:30rem;">
                    <img src="Image'.$count.'.png" alt="Image of '.$cat.'" style="width: 100%;height: 50%" class="card-img-top">
                    <div class="card-body">
                        <h5 class="card-title"><a href="threadlist.php?catid='.$id.'">'.$cat.'</a></h5>
                        <p class="card-text">'.substr($desc,0,90).' ...</p>
                        <a href="threadlist.php?catid='.$id.'" class="btn btn-primary">View Threads</a>
                    </div>
                </div>
            </div>';
            } 
            ?>
        </div>
    </div>
    <?php
    include 'partial/footer.php';

    ?>
   
    
</body>

</html>