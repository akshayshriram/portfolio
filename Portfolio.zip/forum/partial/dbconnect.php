<?php
    $servername = "localhost";
    $username = "easeupgr_forum";
    $password = "=#Wsqb@D;Kg8";
    $database = "easeupgr_forum";
    $conn = mysqli_connect($servername,$username,$password,$database);
    if(!$conn){
        die("Sorry something went wrong on Forum Database Connection");
    }
?>