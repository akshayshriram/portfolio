<?php 
     
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        require 'dbconnect.php';
        $email = $_POST['loginemail'];
        $pass = $_POST['loginpass'];

        $sql = "SELECT * FROM `users` where user_email = '$email'";
        $result = mysqli_query($conn,$sql);
        $num = mysqli_num_rows($result);
        if($num == 1){
            $row = mysqli_fetch_assoc($result);
            if(password_verify($pass,$row['user_pass'])){
                session_start();
                $_SESSION['loggedin']=true;
                $_SESSION['useremail']=$email;
                $_SESSION['sno']=$row['sno'];
                header("location: {$_SERVER['HTTP_REFERER']}");
                exit();
                
            }
            else{

                header("location: {$_SERVER['HTTP_REFERER']}");
                exit();
               
            }
        }
    }
?>