<?php
session_start();
echo '<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="index.php">iQuote</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Dropdown
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="#">Action</a>
            <a class="dropdown-item" href="#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Something else here</a>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#" >Contact</a>
        </li>
      </ul>
      <form class="form-inline my-2 my-lg-0" action="search.php" method="get">
        <input class="form-control col-8 mr-sm-2" name="search" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-success col-3 my-2 ml-2 my-sm-0" type="submit">Search</button>
      </form>';
// logged in session:
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
  echo '
      <p class="text-light my-0 mx-1">Welcome ' . $_SESSION['useremail'] . '</p>
      <a class="btn btn-outline-danger" href="partial/logout.php">Logout</a>
      </div>
      </nav>'; 
} //
else {
  echo '
        <button class="btn btn-outline-light " data-toggle="modal" data-target="#login" >Login</button>
        <button class="btn btn-outline-light mx-2" data-toggle="modal" data-target="#singup">SignUp</button>
        </div>
        </nav>';
}


include 'login.php';
include 'signup.php';



if (isset($_GET['signupsuccess']) && $_GET['signupsuccess'] == "true") {
  echo '<div class="alert alert-success alert-dismissible fade show my-0" role="alert">
        <strong>Success!</strong> You are successfully signed up. Please login.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
        </div>';
} else if (isset($_GET['userexixts'])) {
  echo '<div class="alert alert-warning alert-dismissible fade show my-0" role="alert">
        <strong>Alert!</strong> Username already Exists.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
        </div>';
} else if (isset($_GET['passwordmismatch'])) {
  echo '<div class="alert alert-warning alert-dismissible fade show my-0" role="alert">
        <strong>Alert!</strong> Password do not match.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
        </div>';
} 
else if (isset($_SERVER['loggedin'])=="true") {
  echo '<div class="alert alert-success alert-dismissible fade show my-0" role="alert">
  <strong>SUCCESS!</strong> You are successfully logged in.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true">&times;</span>
        </button>
        </div>';
} 
else if (isset($_SERVER['loggedin'])=="false") {
  echo '<div class="alert alert-success alert-dismissible fade show my-0" role="alert">
  <strong>ERROR!</strong> Login credentials are incorrect.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true">&times;</span>
        </button>
        </div>';
} 

 else {
}
