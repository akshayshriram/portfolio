<?php 
     
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        require 'dbconnect.php';
        $user_email = $_POST['signupEmail'];
        $pass = $_POST['password'];
        $cpass = $_POST['cpassword'];

        //Check wether the user already exists
        $existsql = "SELECT * from `users` where user_email = '$user_email'";
        $result = mysqli_query($conn,$existsql);
        $num = mysqli_num_rows($result);
       
        
        if($num>0)
        {
            $showerror1 =  "User with email id already Exists";
            header("location: /forum/index.php?userexixts");
            exit();
        }
        else
        {   //check if password and confirm password matches
            if($pass == $cpass){
                $hash = password_hash($pass,PASSWORD_DEFAULT);
                $sql = "INSERT INTO `users` (`user_email`, `user_pass`, `timestamp`) 
                VALUES ('$user_email', '$hash', CURRENT_TIMESTAMP)";
                $result = mysqli_query($conn,$sql);
            
                if($result){
                    $showAlert = true;
                 
                    header("location: ../index.php?signupsuccess=true");
                    exit();
                }                
            }
            //if password do not match
            else{
                $showerror2 = "Password doesn't match";
                header("location: ../index.php?passwordmismatch");
                exit();
            }
        }
        
        
    }

    ?>
