<?php
    echo '<div class="container-fluid bg-dark text-light text-center my-0 py-1">
            <p class="my-0">iQuote - Discuss &copy2020 | All rights are reserved. </p>
          </div>';
    
?>