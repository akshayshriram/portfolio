<!-- Modal -->

<div class="modal fade" id="login" tabindex="-1" aria-labelledby="loginLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="loginLabel">Login in iQuote Account</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="/forum/partial/handlelogin.php" method="post">
            <div class="modal-body">
                    <div class="form-group col-lg-8 col-sm-12">
                    <i class="fa fa-envelope"></i> <label for="exampleInputEmail1">Username</label>
                        <input type="text" class="form-control" id="loginemail" name="loginemail" aria-describedby="emailHelp">
                        <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
                    </div>
                    <div class="form-group col-lg-8 col-sm-12">
                    <i class="fa fa-lock"></i> <label for="exampleInputPassword1">Password</label>
                        <input type="password" class="form-control" id="loginpass" name="loginpass">
                    </div>
                        
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
            
        </div>
    </div>
</div>
