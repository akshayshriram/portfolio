<?php
phpinfo();
echo "The date is" . date("Y/m/d H:i:s A");
?>