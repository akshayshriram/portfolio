-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2021 at 06:16 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `google_users`
--

CREATE TABLE `google_users` (
  `id` int(11) NOT NULL,
  `clint_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `google_email` varchar(255) NOT NULL,
  `timestamp` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `google_users`
--

INSERT INTO `google_users` (`id`, `clint_id`, `name`, `last_name`, `google_email`, `timestamp`) VALUES
(1, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 11:12 AM'),
(2, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 11:25 AM'),
(3, '107742000656133766014', 'Akshay', 'Shriram', 'akshayshriram999@gmail.com', '11/11/2020 11:38 AM'),
(4, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 12:48 PM'),
(5, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 1:08 PM'),
(6, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 1:09 PM'),
(7, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 1:15 PM'),
(8, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 1:15 PM'),
(9, '107742000656133766014', 'Akshay', 'Shriram', 'akshayshriram999@gmail.com', '11/11/2020 2:42 PM'),
(10, '107742000656133766014', 'Akshay', 'Shriram', 'akshayshriram999@gmail.com', '11/11/2020 2:42 PM'),
(11, '107742000656133766014', 'Akshay', 'Shriram', 'akshayshriram999@gmail.com', '11/11/2020 2:43 PM'),
(12, '107742000656133766014', 'Akshay', 'Shriram', 'akshayshriram999@gmail.com', '11/11/2020 2:44 PM'),
(13, '107742000656133766014', 'Akshay', 'Shriram', 'akshayshriram999@gmail.com', '11/11/2020 2:46 PM'),
(14, '107742000656133766014', 'Akshay', 'Shriram', 'akshayshriram999@gmail.com', '11/11/2020 2:46 PM'),
(15, '107742000656133766014', 'Akshay', 'Shriram', 'akshayshriram999@gmail.com', '11/11/2020 3:24 PM'),
(16, '107742000656133766014', 'Akshay', 'Shriram', 'akshayshriram999@gmail.com', '11/11/2020 3:24 PM'),
(17, '107742000656133766014', 'Akshay', 'Shriram', 'akshayshriram999@gmail.com', '11/11/2020 3:24 PM'),
(18, '107742000656133766014', 'Akshay', 'Shriram', 'akshayshriram999@gmail.com', '11/11/2020 3:25 PM'),
(19, '107742000656133766014', 'Akshay', 'Shriram', 'akshayshriram999@gmail.com', '11/11/2020 3:25 PM'),
(20, '107742000656133766014', 'Akshay', 'Shriram', 'akshayshriram999@gmail.com', '11/11/2020 3:25 PM'),
(21, '107742000656133766014', 'Akshay', 'Shriram', 'akshayshriram999@gmail.com', '11/11/2020 3:25 PM'),
(22, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 3:26 PM'),
(23, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 3:26 PM'),
(24, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 3:35 PM'),
(25, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 3:37 PM'),
(26, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 3:56 PM'),
(27, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 4:16 PM'),
(28, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 4:18 PM'),
(29, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 4:19 PM'),
(30, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 6:38 PM'),
(31, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 8:21 PM'),
(32, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 8:22 PM'),
(33, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 8:23 PM'),
(34, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 8:24 PM'),
(35, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 8:25 PM'),
(36, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 8:27 PM'),
(37, '103815555570797953131', 'Akshay', 'Shriram', 'asshriram@mitaoe.ac.in', '11/11/2020 8:29 PM');

-- --------------------------------------------------------

--
-- Table structure for table `logindetail`
--

CREATE TABLE `logindetail` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `logindetail`
--

INSERT INTO `logindetail` (`id`, `username`, `password`) VALUES
(1, 'akshay', 'jaishriram'),
(2, 'shrutika', 'shriram1197'),
(3, 'murli', 'shrutz'),
(4, 'mom', 'mom12345'),
(8, 'pratik', 'whoareyou'),
(9, 'akshay', 'sjdhf');

-- --------------------------------------------------------

--
-- Table structure for table `otp`
--

CREATE TABLE `otp` (
  `id` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `userdetail`
--

CREATE TABLE `userdetail` (
  `sno` int(11) NOT NULL,
  `name` text NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` text NOT NULL,
  `mobile` text NOT NULL,
  `address` text NOT NULL,
  `pincode` varchar(6) NOT NULL,
  `password` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdetail`
--

INSERT INTO `userdetail` (`sno`, `name`, `username`, `email`, `mobile`, `address`, `pincode`, `password`, `timestamp`) VALUES
(1, 'Akshay', 'test123', 'asshriram@mitaoe.ac.in', '8888888888', '234, solapur, sd', '400002', '$2y$10$8Ezpq.SiAHoOSgNlvJpWoeeFXqt08Z3xg.CDlNLVN5rwG/tYznrPi', '2020-10-29 19:09:12'),
(2, 'Yash Patil', 'yash123', 'yashpatil@gmail.com', '8787878787', '15, Dhanori, Pune', '411031', '$2y$10$BV0eJdbe4yd1QEEN6goGwu9kbNGF2uG2Gk44eR1HuzsbsxZ.azo7.', '2020-11-10 11:55:18'),
(5, 'Akshay Shriram', 'akshay', 'asshriram@mitaoe.ac.in', '8888702604', '15, Yerwada,Pune', '411006', '$2y$10$JN76XLys1wFeXUVeMKf.NOxvqytXxuckjb3vTV/LMLW.jBa6axzpm', '2020-11-11 19:07:41'),
(6, 'Akshay', 'akshay123', 'aass@asd.as', '8934567893', '12, vidi', '411006', '$2y$10$cYx6eXAXNp/Kbf8iStCZw.fz4749lVnIx4QDuZYPhMSBuY2C9dMTC', '2021-05-27 17:26:07'),
(7, 'Swapnil Chitken', 'swapnil', 'swapnil@gmail.com', '8805617577', '15, vidi kamghar, pune', '411006', '$2y$10$JtAv.ViHvB160LA59ZezUuvpAFcCYVsf.VgGPpBnjfTFL/n6vgkSG', '2021-06-22 19:12:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `google_users`
--
ALTER TABLE `google_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logindetail`
--
ALTER TABLE `logindetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `otp`
--
ALTER TABLE `otp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userdetail`
--
ALTER TABLE `userdetail`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `google_users`
--
ALTER TABLE `google_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `logindetail`
--
ALTER TABLE `logindetail`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `otp`
--
ALTER TABLE `otp`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `userdetail`
--
ALTER TABLE `userdetail`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
