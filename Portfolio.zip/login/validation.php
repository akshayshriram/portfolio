<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invalid Credentionals | Login System | Made Easy</title>

    <!-- Alertify CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/css/alertify.min.css" integrity="sha512-IXuoq1aFd2wXs4NqGskwX2Vb+I8UJ+tGJEu/Dc0zwLNKeQ7CW3Sr6v0yU3z5OQWe3eScVIkER4J9L7byrgR/fA==" crossorigin="anonymous" />

    <!-- Alertify Link -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/alertify.min.js" integrity="sha512-JnjG+Wt53GspUQXQhc+c4j8SBERsgJAoHeehagKHlxQN+MtCCmFDghX9/AcbkkNRZptyZU4zC8utK59M5L45Iw==" crossorigin="anonymous"></script>
</head>
<body>

</body>
</html>


<?php
$name = $_POST['name'];
$username = $_POST['username'];
$email = $_POST['email'];
// $mobile = $_POST['mobile'];
// $address = $_POST['address'];
// $pincode = $_POST['pincode'];
$password = $_POST['password'];
$cpassword = $_POST['cpassword'];

//For Full Name
$regname = "/^[a-zA-Z ]{3,}+$/";
if (!preg_match($regname, $name)) {
    $name_error = '**Name should not contain special character or numerical value';
    echo "<b></b><script>
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.success('" . $name_error . "');
                    </script>";
}
// For username
$regusername = "/^[a-zA-Z\d ]{3,20}+$/";
if (!preg_match($regusername, $username)) {
    $username_error = '**Username should not contain special character';
    echo "<b></b><script>
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.success('" . $username_error . "');
                    </script>";
}
// For Email
$regemail = "/^[a-zA-Z\d_]+@[a-zA-Z\d\._]+\.[a-zA-Z\d\.]{2,}+$/";
if (!preg_match($regemail, $email)) {
    $email_error = "**Invalid email format";
    echo "<b></b><script>
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.success('" . $email_error . "');
                    </script>";
}
// //For mobile number
// $regmobile = "/^([\+91 ][6-9]{1}[0-9]{9})|([6-9]{1}[0-9]{9})$/";
// if (!preg_match($regmobile, $mobile)) {
//     $mobile_error = '**Invalid Mobile Number';
//     echo "<b></b><script>
//                         alertify.set('notifier', 'position', 'top-right');
//                         alertify.success('" . $mobile_error . "');
//                     </script>";
// }
// // For Address
// $regaddress = "/^\d+[\/\,\s]+[ a-zA-Z\d\s\,\. ]+$/";
// if (!preg_match($regaddress, $address)) {
//     $address_error = '**Invalid Adress';
// }
// For Pincode
// $regpincode = "/^[0-9]{6}$/";
// if (!preg_match($regpincode, $pincode)) {
//     $pincode_error = '**Invalid Pincode';
//     echo "<b></b><script>
//                         alertify.set('notifier', 'position', 'top-right');
//                         alertify.success('" . $pincode_error . "');
//                     </script>";
// }
// For Password
$regpassword = "/^\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])\S*$/";
if (!preg_match($regpassword, $password)) {
    $password_error = '**At least 8 characters including uppercase, lowercase, digits.';
    echo "<b></b><script>
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.success('" . $password_error . "');
                    </script>";
}
if($cpassword != $password){
    $cpassword_error = "**Confirm Password and Password must be same.";
    echo "<b></b><script>
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.success('" . $cpassword_error . "');
                    </script>";
}

if ((!preg_match($regname, $name)) or (!preg_match($regusername, $username)) or (!preg_match($regemail, $email))
    // or (!preg_match($regmobile, $mobile)) or (!preg_match($regaddress, $address)) or (!preg_match($regpincode, $pincode))
    or (!preg_match($regpassword, $password))) {
    $insert = false;
    include 'signup.php';
} else {
    $insert = true;
    include 'signup.php';
}

?>