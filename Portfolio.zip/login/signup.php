<?php
require('./partial/dbconnect.php');

$showAlert = false;
$login = false;
$showError = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $mobile = 'null'; //$_POST['mobile']
    $address = 'null'; //$_POST['address']
    $pincode = 'null'; //$_POST['pincode']
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    // $exits = false;
    //Checking the existence of the user
    
    $sqlExists = "SELECT * FROM `userdetail` WHERE `username` LIKE '$username'";
    $result = mysqli_query($conn, $sqlExists);
    $numExists = mysqli_num_rows($result);
    if ($numExists > 0) {
        $showError = "Username already Exists.";
    } 
    else {
        
        if (($cpassword == $password) ) {
            if($insert){
                $hash = password_hash($password,PASSWORD_DEFAULT);
                
    
                $sql = "INSERT INTO `userdetail` ( `name`, `username`, `email`, `mobile`, `address`, `pincode`, `password`, `timestamp`) 
                VALUES ('$name', '$username', '$email', '$mobile', '$address', '$pincode', '$hash', CURRENT_TIMESTAMP);";
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    $showAlert = "Your account has been created and your details are encrypted.";
                }

            }
        } 
        else {
            
            $cpassword_error = "**Confirm Password and Password must be same.";
           
        }
    }
}


?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>Login System | Made Easy</title>
</head>

<body>
    <?php require('partial/nav.php');
    if ($showAlert) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>SUCCESS!</strong> '.$showAlert.'
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>';
        
    }
    if ($showError) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>ERROR!</strong> '.$showError.'
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>';
    }
    


    ?>


    <div class="container">
        <h1 class="text-center mt-3">Sign Up here</h1>
        <form action="./validation.php" method="POST">
            <!-- For Fullname -->
            <div class="form-group col-lg-4 col-sm-12">
                <label for="name">Full Name</label>
                <input required type="text" placeholder="Full name"  class="form-control" id="name"
                    name="name" aria-describedby="emailHelp">
                <?php
                if (isset($name_error)) { 
                    echo '<h6> '. $name_error .'</h6>';
                 } ?>
            </div>

            <!-- For username -->
             <div class="form-group col-lg-4 col-sm-12">
                <label for="username">Username</label>
                <input required type="text" placeholder="Ex. abc123" " class="form-control" id="username"
                    name="username" aria-describedby="emailHelp">
                <?php
                if (isset($username_error)) { 
                    echo '<h6> '. $username_error .'</h6>';
                 } ?>
            </div>
            <!-- For Email -->
             <div class="form-group col-lg-4 col-sm-12">
                <label for="email">Email</label>
                <input required  type="email" placeholder="abc@gmail.com" class="form-control" id="email"
                    name="email">
                <?php
                if (isset($email_error)) { 
                    echo '<h6> '. $email_error .'</h6>';
                 }
                  ?> 
            </div>
            <!-- For Mobile number -->
            <!-- <div class="form-group col-lg-4 col-sm-12">
                <label for="mobile">Mobile Number</label>
                <input required  type="mobile" placeholder="+91 8888888888 OR 8888888888"
                    class="form-control" id="mobile" name="mobile">
                <?php
                // if (isset($mobile_error)) { 
                //     echo '<h6> '. $mobile_error .'</h6>';
                //  } 
                 ?>
            </div> -->
            <!-- For Address -->
             <!-- <div class="form-group col-lg-4 col-sm-12">
                <label for="address">Address</label>
                <input required type="text"  placeholder="15,Vishrantwadi,Pune" class="form-control"
                    id="address" name="address" aria-describedby="emailHelp"> 
                <?php
                // if (isset($address_error)) { 
                //     echo '<h6> '. $address_error .'</h6>';
                //  }
                 ?>

            </div> -->
            <!-- For Pincode -->
            <!-- <div class="form-group col-lg-4 col-sm-12">
                <label for="pincode">Pincode</label>
                <input required type="text"  placeholder="400001" class="form-control"
                    id="pincode" name="pincode" aria-describedby="emailHelp">
                <?php
                // if (isset($pincode_error)) { 
                //     echo '<h6> '. $pincode_error .'</h6>';
                //  } 
                 ?>

            </div> -->

            <div class="form-group col-lg-4 col-sm-12">
                <label for="password">Password</label>
                <input required  type="password" class="form-control" id="password" name="password">
                <?php
                if (isset($password_error)) { 
                    echo '<h6> '. $password_error .'</h6>';
                 } ?>
            </div>
            <div class="form-group col-lg-4 col-sm-12">
                <label for="password">Confirm Password</label>
                <input required  type="password" class="form-control" id="cpassword" name="cpassword">
                <small class="form-text text-muted">Please! Carefully write the above password</small>
                <?php
                if (isset($cpassword_error)) { 
                    echo '<h6> '. $cpassword_error .'</h6>';
                 } ?>
                
            </div>
            <button type="submit" class="btn btn-primary my-3">Submit</button>
        </form>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"
        crossorigin="anonymous"></script>
</body>

</html>