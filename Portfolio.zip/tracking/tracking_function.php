<?php
    //Connect the Databse 

    require('./partial/DBconnect.php');
    
    //retrieve php
    require('./partial/retrieve.php');

    //Insert php
    require('./partial/insert.php');

    //Obect of DBcontroller
    $db = new DBcontroller;

   
    //Common retrieve object
    $retrieve = new retrieve($db);

    //Insert object
    $insert = new insert($db);

    
?>