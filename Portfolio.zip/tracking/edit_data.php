<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EaseWeb | Edit Site Details</title>
    <!-- Bootstrap CSS Link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <!-- Alertify CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/css/alertify.min.css" integrity="sha512-IXuoq1aFd2wXs4NqGskwX2Vb+I8UJ+tGJEu/Dc0zwLNKeQ7CW3Sr6v0yU3z5OQWe3eScVIkER4J9L7byrgR/fA==" crossorigin="anonymous" />

    <!-- Alertify Link -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/alertify.min.js" integrity="sha512-JnjG+Wt53GspUQXQhc+c4j8SBERsgJAoHeehagKHlxQN+MtCCmFDghX9/AcbkkNRZptyZU4zC8utK59M5L45Iw==" crossorigin="anonymous"></script>

</head>

<body>
    <?php
    require_once('tracking_function.php');
    $data = $retrieve->getData('tracking_images');

    // if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //     if (isset($_POST['delete_submit'])) {
    //         $client_id = $_POST['client_id'];
    //         $building_name = $_POST['building_name'];
    //         $image_file_name = $_POST['image_file_name'];
    //         $delete = $insert->deleteImage($client_id, $building_name, $image_file_name);
    //         if ($delete) {
    //             echo "<script>
    //                             alertify.set('notifier', 'position', 'top-right');
    //                             alertify.warning('Image Deleted!!!');
    //                         </script>";
    //         }
    //     }
    // }

    ?>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="/">EaseWeb</a>
        </div>
    </nav>
    <div class="container table-responsive">
        <h1>Edit Site Work Details</h1>
        <table class="table table-responsive" id="delete">
            <thead class="table-dark">
                <tr>
                    <th scope="col">SR.NO</th>
                    <th scope="col">Client Id</th>
                    <th scope="col">Client Name</th>
                    <th scope="col">Building Name</th>
                    <th scope="col">Image</th>
                    <th scope="col">Image Name</th>
                    <th scope="col">Delete</th>
                </tr>
            </thead>
            <?php array_map(function ($item) { ?>
                <tbody id="delete">
                    <tr>
                        <td><?php echo $item['image_id'] ?></td>
                        <td><?php echo $item['client_id'] ?></td>
                        <td><?php echo $item['client_name'] ?></td>
                        <td><?php echo $item['building_name'] ?></td>
                        <td><?php echo '<img src="data:image/jpg;charset=utf8;base64,' . base64_encode($item['image']) . '" height="100" width="100" alt="">'; ?></td>
                        <td><?php echo $item['image_file_name'] ?></td>
                        <td>
                            <form id="form<?php echo $item['image_id']; ?>" method="POST">
                                <input type="hidden" name="image_id" value="<?php echo $item['image_id'] ?>">
                                <input type="button" onclick="edit_details(<?php echo $item['image_id'] ?>)" class="btn btn-danger" value="Delete">
                            </form>
                        </td>
                    </tr>
                </tbody>
            <?php }, $data); ?>
        </table>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>

    <script>
        function edit_details(id) {
            $.ajax({
                url: '../tracking/edit_ajax.php',
                type: 'POST',
                data: $('#form' + id).serialize(),
                success: function(result) {
                    $('#delete').html(result);
                }
            })
        }
    </script>
</body>

</html>