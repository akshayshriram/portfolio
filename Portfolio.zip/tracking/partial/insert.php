<?php

class insert
{
    public $db = null;
    public function __construct(DBcontroller $db)
    {
        if (!isset($db->conn)) return null;
        $this->db = $db;
    }
    //INSERTION of client data
    public function clientData($client_name = null, $building_name = null, $text = null)
    {
        if ($client_name != null) {
            $query = "UPDATE `tracking` SET `$building_name` = '$text' WHERE `tracking`.`client_name` = '$client_name'";
            $result = $this->db->conn->query($query);
    
    
            return $result;
        }
    }
    //INSERTION of client image
    public function clientImage($client_id = null,$client_name = null,$building_name = null, $image = null,$image_file_name = null, $time_stamp = null)
    {
        if ($client_name != null && $building_name !=null) {
            $query ="INSERT into `tracking_images` (`client_id`,`client_name`,`building_name`,`image`,`image_file_name`, `time_stamp`) VALUES ('{$client_id}','{$client_name}','{$building_name}','{$image}','{$image_file_name}','{$time_stamp}')";
            
            $result = $this->db->conn->query($query);
            

            return $result;
        }
    }
    
    //DELETION of client image
    public function deleteImage($image_id = null)
    {
        if ($image_id != null) {
            $query ="DELETE FROM `tracking_images` WHERE image_id = '{$image_id}'";
            $result = $this->db->conn->query($query);
            

            return $result;
        }
    }
}


?>