<?php
    class DBcontroller 
    {
        //Database Connection Properties
        protected $host = 'localhost';
        protected $user = 'easeupgr_admin';
        protected $password = '!obTk{tGrZY3';
        protected $database = 'easeupgr_work_status';

        //connection property
        public $conn = null;
        
        //call constructor
        public function __construct()
        {
            $this->conn = mysqli_connect($this->host,$this->user,$this->password,$this->database);
            if(!$this->conn){
                echo 'Something went wrong in the DBconnection';
                
            }
                                
        }
        public function __destruct()
        {
            $this->CloseConnection();
        }
        //For MySQLi closing connection
        protected function CloseConnection(){
            if($this->conn !=null){
                $this->conn->close();
                $this->conn = null;
            }
        }
    }
    
    
?>