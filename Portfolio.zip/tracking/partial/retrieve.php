<?php

class retrieve
{
    public $db = null;
    public function __construct(DBcontroller $db)
    {
        if (!isset($db->conn)) return null;
        $this->db = $db;
    }

    //Fetch product data using getData method
    public function getData($table = 'cart')
    {
        $result = $this->db->conn->query("SELECT * FROM {$table}");
        $resultArray = array();

        // fetch product data one by one
        while ($item = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $resultArray[] = $item;
        }
        return $resultArray;
    }

    // Get Images of work site
    public function getImages($client_id = null, $building_name = null)
    {

        if ($client_id != null && $building_name != null) {
            $result = $this->db->conn->query("SELECT * FROM `tracking_images` WHERE `client_id` = '{$client_id}' AND `building_name` = '{$building_name}'");
            $resultArray = array();

            // fetch product data one by one
            while ($item = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $resultArray[] = $item;
            }
            return $resultArray;
        }
    }

    // Recent Update Record
    public function recentRecord($client_id = null, $building_name = null)
    {
        $result = $this->db->conn->query("SELECT time_stamp FROM `tracking_images` WHERE `client_id` = '{$client_id}' AND `building_name` = '{$building_name}' ORDER BY image_id DESC LIMIT 1");
        $resultArray = array();
        // fetch product data one by one
        while ($item = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $resultArray[] = $item;
        }
        return $resultArray;
    }
}

?>