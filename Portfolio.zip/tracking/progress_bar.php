<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EaseUpgrade | Tracking Application</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        ul {
            list-style: none;
        }

        body {
            background: #fff;
            height: 100vh;
        }

        .navmenu {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
        }

        .navmenu ul {
            padding-left: 50px;
            position: relative;

        }

        .navmenu ul::after {
            content: '';
            position: absolute;
            width: 3px;
            height: calc(100% - 65px);
            left: 40px;
            top: 0;
            background: #3742da;
            z-index: -1;
            margin-top: 29px;
            animation: loader 4s ease forwards;

        }

        .navmenu ul li::after {
            content: '';
            position: absolute;
            width: 3px;
            height: calc(100% - 65px);
            left: 70px;
            top: 0;
            background: yellow;
            z-index: 100;
            margin-top: 29px;
            animation: bar 4s ease forwards;
            margin-left: -30px;
        }
        /* First stage 30% 
        second stage 55% 
        third stage 80% */
        @keyframes bar {
            0% {
                height: 0%;
            }

            100% {
                height: 60%;
            }

        }

            .navmenu ul li {
                padding: 30px 0;
                padding-left: 20px;
            }

            .navmenu ul li a {
                text-decoration: none;
                position: relative;
                color: #3742da;
                font-size: 1.5rem;
                line-height: 1rem;
                font-weight: 500;

            }

            .navmenu ul li a:before {
                content: "";
                position: absolute;
                background: #fff;
                width: 18px;
                height: 18px;
                left: -37px;
                top: 50%;
                transform: translateY(-50%);
                border-radius: 50px;
                border: 4px solid #3742da;
                transition: background 250ms;
                z-index: 1000;
            }
            

            .navmenu ul li a.active {
                font-weight: 700;
            }

            .navmenu ul li a.active1::before {
                background: #3742da;                
                animation: spot1 1s ease forwards;
            }
            .navmenu ul li a.active2::before {
                background: #3742da;                
                animation: spot2 1.5s ease forwards;
            }
            .navmenu ul li a.active3::before {
                background: #3742da;                
                animation: spot3 3s ease forwards;
            }
            .navmenu ul li a.active4::before {
                background: #3742da;                
                animation: spot4 4s ease forwards;
            }
            @keyframes spot1 {
            0% {
                background: #fff;
            }

            100% {
                background: #3742da;
            }

        }
            @keyframes spot2 {
            0% {
                background: #fff;
            }
            50% {
                background: #fff;
            }

            100% {
                background: #3742da;
            }

        }
            @keyframes spot3 {
            0% {
                background: #fff;
            }
            50% {
                background: #fff;
            }

            100% {
                background: #3742da;
            }
        }
            @keyframes spot4 {
            0% {
                background: #fff;
            }
            50% {
                background: #fff;
            }

            100% {
                background: #3742da;
            }

        }
    </style>

</head>

<body>
    <div class="navmenu">
        <ul>
            <li><a href="" class="active1">Services</a></li>
            <li><a href="" class="active2">Services</a></li>
            <li><a href="" class="active3">Services</a></li>
            <li><a href="" class="active">Services</a></li>
        </ul>
    </div>
</body>

</html>