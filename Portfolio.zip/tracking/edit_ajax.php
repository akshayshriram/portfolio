<?php
require_once('tracking_function.php');

$image_id = $_POST['image_id'];
$delete = $insert->deleteImage($image_id);
if ($delete) {
    echo "<script>
                                alertify.set('notifier', 'position', 'top-right');
                                alertify.warning('Image Deleted!!!');
                            </script>";
}

$data = $retrieve->getData('tracking_images');
?>

<table class="table table-responsive" id="delete">
            <thead class="table-dark">
                <tr>
                    <th scope="col">SR.NO</th>
                    <th scope="col">Client Id</th>
                    <th scope="col">Client Name</th>
                    <th scope="col">Building Name</th>
                    <th scope="col">Image</th>
                    <th scope="col">Image Name</th>
                    <th scope="col">Delete</th>
                </tr>
            </thead>
            <?php array_map(function ($item) { ?>
                <tbody id="delete">
                    <tr>
                        <td><?php echo $item['image_id'] ?></td>
                        <td><?php echo $item['client_id'] ?></td>
                        <td><?php echo $item['client_name'] ?></td>
                        <td><?php echo $item['building_name'] ?></td>
                        <td><?php echo '<img src="data:image/jpg;charset=utf8;base64,' . base64_encode($item['image']) . '" height="100" width="100" alt="">'; ?></td>
                        <td><?php echo $item['image_file_name'] ?></td>
                        <td>
                            <form id="form<?php echo $item['image_id']; ?>" method="POST">
                                <input type="hidden" name="image_id" value="<?php echo $item['image_id'] ?>">
                                <input type="button" onclick="edit_details(<?php echo $item['image_id'] ?>)" class="btn btn-danger" value="Delete">
                            </form>
                        </td>
                    </tr>
                </tbody>
            <?php }, $data); ?>
        </table>