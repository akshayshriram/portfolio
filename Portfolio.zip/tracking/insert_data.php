<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EaseUpgrade | Insert Site Details</title>
    <!-- Bootstrap CSS Link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <!-- Alertify CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/css/alertify.min.css" integrity="sha512-IXuoq1aFd2wXs4NqGskwX2Vb+I8UJ+tGJEu/Dc0zwLNKeQ7CW3Sr6v0yU3z5OQWe3eScVIkER4J9L7byrgR/fA==" crossorigin="anonymous" />

    <!-- Alertify Link -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/alertify.min.js" integrity="sha512-JnjG+Wt53GspUQXQhc+c4j8SBERsgJAoHeehagKHlxQN+MtCCmFDghX9/AcbkkNRZptyZU4zC8utK59M5L45Iw==" crossorigin="anonymous"></script>


</head>
<?php
require_once 'tracking_function.php';
$insert = new insert($db);
$client_data = $retrieve->getData('tracking');
// print_r($client_data);

date_default_timezone_set("Asia/Calcutta"); //India time (GMT+5:30)
$time_stamp = date('d/m/Y g:i A');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $status = $statusMsg = '';
    if (isset($_POST['client_data-submit'])) {
        $client_name = $_POST['client_name'];
        foreach ($client_data as $item):
            if (array_search($client_name, $item)) {
                $client_id = $item['client_id'];
            }
        endforeach;
        // print_r($client_id);
        $building_name = $_POST['building_name'];
        $text_area = $_POST['text_area'];
        $status = 'error';
        $client_details = $insert->clientData($client_name, $building_name, $text_area);
        if ($client_details) {
            echo "<script>
                                alertify.set('notifier', 'position', 'top-right');
                                alertify.success('Details Uploaded Successfully!!!');
                            </script>";
        }
        if (!empty($_FILES["image"]["name"])) {
            $fileName = basename($_FILES["image"]["name"]);
            $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
            $allowTypes = array('jpg', 'png', 'jpeg', 'gif', 'JPG', 'JPEG', 'PNG');
            if (in_array($fileType, $allowTypes)) {
                $image = $_FILES['image']['tmp_name']; //This is a temporary file name

                // Image Compressor for jpeg, jpg, png, gif
                $imageNameCreate = "WorkStatus_" . time();
                $imageNumberCreate = rand(1000, 10000);
                $compressedImageName = $imageNameCreate . $imageNumberCreate . ".jpeg";
                $imageDestination = 'uploads/' . $compressedImageName;

                $info = getimagesize($image);

                if ($info['mime'] == 'image/jpeg') {
                    $image = imagecreatefromjpeg($image);
                } elseif ($info['mime'] == 'image/gif') {
                    $image = imagecreatefromgif($image);
                } elseif ($info['mime'] == 'image/png') {
                    $image = imagecreatefrompng($image);
                } elseif ($info['mime'] == 'image/jpg') {
                    $image = imagecreatefromjpeg($image);
                }

                // quality is optional, and ranges from 0 (worst quality, smaller file) to 100 (best quality, biggest file).
                $quality = '25';

                //save it
                $image = imagejpeg($image, $imageDestination, $quality);

                $imgContent = addslashes(file_get_contents($imageDestination));

                // Insert image content into database
                $insert1 = $insert->clientImage($client_id, $client_name, $building_name, $imgContent, $compressedImageName, $time_stamp);
                $imageName = $image;
                unlink($imageDestination);

                if ($insert1) {
                    $status = 'success';
                    $statusMsg = "File uploaded successfully.";
                    //     echo "\b<script>
                    //     alertify.set('notifier', 'position', 'top-right');
                    //     alertify.success('" . $status. "');
                    // </script>";

                } else {
                    $statusMsg = "File upload failed, please try again.";
                }
            } else {
                $statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
            }
        } else {
            $statusMsg = 'Please select an image file to upload.';
        }

    }

    echo "<b></b><script>
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.success('" . $statusMsg . "');
                    </script>";
    if (isset($_POST['client_name-submit'])) {
            $client_link = $_POST['client_name'];
            header("location: ./tracking_page.php?client_name=$client_link");
    }
}

?>

<body>
        <!-- Header Strip -->
        <div class="strip sticky-top bg-info bg-gradient d-flex justify-content-between px-4 py-1">
            <a class="nav-link p-1 text-dark" href="https://easeweb.easeupgrade.com">EaseWeb Developers</a>
            <a class="nav-link p-1 btn btn-light text-dark" href="https://easeweb.easeupgrade.com">Home page</a>
        </div>
    <div class="container">
        <h1>Upload Client Details</h1>
        <hr>
        <form method="POST" enctype="multipart/form-data">
            <select name="client_name" class="form-select mb-3" aria-label="Default select example">
                <option value="0" selected>Client Name</option>
                <?php array_map(function ($item) {?>
                    <option value="<?php echo $item['client_name']; ?>"><?php echo $item['client_name']; ?></option>
                <?php }, $client_data)?>
            </select>

            <select name="building_name" class="form-select" aria-label="Default select example">
                <option value="0" selected>Building Name</option>
                <option value="building_A">Building A</option>
                <option value="building_B">Building B</option>
                <option value="building_C">Building C</option>
            </select>
            <div class="form-floating my-3">
                <input type="text" name="text_area" class="form-control" placeholder="Leave a comment here" id="text_area" style="height: 100px"></textarea>
                <label for="text_area">Comments</label>
            </div>
            <div class="mb-3">
                <input class="form-control" type="file" name="image" id="image">
            </div>
            <button type="submit" name="client_data-submit" class="btn btn-success font-size-12">Submit</button>
            <a href="edit_data.php" class="btn btn-primary">Edit</a>
        </form>

        <h1 class="mt-5">Get Client Details</h1>
        <hr>
        <form method="POST" enctype="multipart/form-data">
            <select name="client_name" class="form-select" aria-label="Default select example">
                <option value="0" selected>Select Client Name</option>
                <option value="Yashashree Group">Yashashree Group</option>
                <option value="Arise Group">Arise Group</option>
                <option value="Prestige Group">Prestige Group</option>
                <option value="GK Developer">GK Developer</option>
                <option value="Pritam Sir, World Pride City">Pritam Sir, World Pride City</option>
            </select>

            <button type="submit" name="client_name-submit" class="btn btn-success font-size-12 mt-3">Submit</button>
        </form>
        </div>

    <!-- <script>
        alertify.set('notifier', 'position', 'top-right');
        alertify.success('Opened!!!');
    </script> -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>