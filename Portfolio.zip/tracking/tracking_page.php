<?php
require_once('tracking_function.php');
$live_data = $retrieve->getData('tracking');
$client_name = $_GET['client_name'];
foreach ($live_data as $item):
    if($item['client_name'] == $_GET['client_name']) {
        $client_id = $item['client_id'];
        // return $client_id;
    }
endforeach;



// print_r($client_id);

// date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30) 
// $timestamp= date('d/m/Y g:i A');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EaseWeb | Tracking Application</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css" integrity="sha512-UTNP5BXLIptsaj5WdKFrkFov94lDx+eBvbKyoe1YAfjeRPC+gT5kyZ10kOHCfNZqEui1sxmqvodNUx3KbuYI/A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css" integrity="sha512-OTcub78R3msOCtY3Tc6FzeDJ8N9qvQn1Ph49ou13xgA9VsH9+LRxoFU6EqLhW4+PKRfU+/HReXmSZXHEkpYoOA==" crossorigin="anonymous" referrerpolicy="no-referrer" />


    <style>
        *,
        html {
            margin: 0;
            padding: 0;
            /* overflow: hidden; */
            scroll-behavior: smooth;
        }

        /* Animation ============================================= */
        /* // Edit these at random intervals to change the animation. */
        @keyframes loader {

            0% {
                width: 0;
            }

            /*
            Use 0% as a starting point and use php template variable toend the progress bar like 75%
            */
            40% {
                width: 40%;

            }
        }

        /* // Bar ============================================ */
        .progress-bar {
            border-radius: 60px;
            /* overflow: hidden; */
            width: 65vh;
            left: -30vh;
            top: 40vh;
            background-color: gainsboro;
            position: relative;
            transform: rotate(90deg);

        }

        .progress-bar span {
            display: block;

        }

        .bar {
            background: rgba(0, 0, 0, 0.075);
        }

        .progress {
            animation: loader 4s ease forwards;
            /* // Change the animation fill mode 'infinite' to 'forwards' to stop the animation from repeating. */

            background: #75b800;
            color: #fff;
            padding: 5px;
            width: 60%;
        }

        .at20 {
            left: 30vh;
            margin-top: 3vh;

        }

        .at40 {
            left: 30vh;
            margin-top: 13vh;
        }

        .at60 {
            left: 30vh;
            margin-top: 13vh;
        }

        .at80 {
            left: 30vh;
            margin-top: 13vh;
        }

        .at100 {
            left: 30vh;
            margin-top: 13vh;
        }

        #scroll {
            vertical-align: top;
            transform: rotate(90deg);
            margin-top: 80px;
            /* position: fixed; */
            float: right;
            z-index: 1000;
            text-decoration: none;
            color: black;

        }
    </style>
</head>

<body>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="/">EaseWeb</a>
        </div>
    </nav>

    <div class="container">
        <!-- Start Live Status Bar -->
        <div class="row">
            <div class="col-1">
                <div class="progress-bar">
                    <span class="bar">
                        <span class="progress"></span>
                    </span>
                </div>
            </div>
            <div class="col-11" style="padding-left: 80px;">
                <div class="at20">
                    <?php array_map(function ($item) { 
                        if($item['client_name'] == $_GET['client_name']) {?>
                        <h5 style="top:50px">EaseUpgrade Solutions Welcomes <?php echo $item['client_name']; ?>!!!</h5>
                    <?php }}, $live_data); ?>
                </div>
                <div class="at40">
                    <h5>Survey</h5>
                    <a id="scroll" href="#client_data">Scroll Down</a>
                </div>
                <div class="at60">
                    <h5>Planning</h5>
                </div>
                <div class="at80">
                    <h5>Work in Progress</h5>
                </div>
                <div class="at100">
                    <h5>Project Completed Successfully!!!</h5>
                </div>

            </div>
        </div>

        <!-- End Live Status Bar -->
        <hr>

        <!--Start Live Photos and text content -->

        <!-- Building A -->
        <div class="container" id="client_data">
            <div class=" p-2 my-3 row border border-warning border-3">
                <h2> Work Status </h2>
                <div class="owl-carousel owl-theme">
                    <?php $live_photos = array_reverse($retrieve->getImages($client_id, 'building_A'));
                    array_map(function ($image) { ?>
                        <div class="item">
                            <img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($image['image']); ?>" height="200" width="300" alt="">
                        </div>
                    <?php }, $live_photos); ?>
                </div>

                <?php
                array_map(function ($live_text) { 
                    if($live_text['client_name'] == $_GET['client_name']) {?>
                    <!-- Start Text here -->
                    <div class="border border-dark border-2">
                        <h6 class="p-0 m-0"><?php echo $live_text['building_A'] ?></h6>
                    </div>

                    <!-- End Text here -->

                <?php }}, $live_data) ?>

                <?php $live_time_stamp = $retrieve->recentRecord($client_id, 'building_A');
                array_map(function ($live_time_stamp) { ?>
                    <div class="text-end">
                        Recent Update: <?php echo $live_time_stamp['time_stamp'] ?>
                    </div>
                <?php }, $live_time_stamp); ?>

            </div>

        </div>
        <!--End Live Photos and text content -->

    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.js" integrity="sha512-n/4gHW3atM3QqRcbCn6ewmpxcLAHGaDjpEBu4xZd47N0W2oQ+6q7oc3PXstrJYXcbNU1OHdQ1T7pAP+gi5Yu8g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js" integrity="sha512-gY25nC63ddE0LcLPhxUJGFxa2GoIyA5FLym4UJqHDEMHjp8RET6Zn/SHo1sltt3WuVtqfyxECP38/daUc/WVEA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        $('.owl-carousel').owlCarousel({

            margin: 10,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 3
                },
                1000: {
                    items: 5
                }
            }
        })
    </script>
</body>

</html>